/home/secadmin/Fuzzing/afl-2.52b/afl-fuzz -i input -o output -- ./a.out 
