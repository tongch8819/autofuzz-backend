#!/bin/bash

/home/chengtong/auto-fuzz/dev/afl/afl-gcc -o demo target.c